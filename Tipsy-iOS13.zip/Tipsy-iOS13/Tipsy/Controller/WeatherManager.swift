//
//  WeatherManager.swift
//  Clima
//
//  Created by Nodir on 1/15/20.
//  Copyright © 2020 App Brewery. All rights reserved.
//

import Foundation
